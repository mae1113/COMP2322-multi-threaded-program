# Multi-Threaded HTTP Web Server and Client

This project implements a simple multi-threaded HTTP web server and client in Python. The server can handle multiple client requests concurrently and serves static files from a specified directory (`httpdoc`). The client sends HTTP requests to the server and displays the server's responses.

---

## Features

- **Multi-Threaded Server**: Handles multiple client connections simultaneously using Python's `threading` module.
- **Static File Serving**: Serves files like `.html`, `.txt`, `.png`, and `.jpg` from the `httpdoc` directory.
- **HTTP Protocol Support**:
  - Supported methods: `GET`, `HEAD`.
  - Handles headers like `If-Modified-Since` and `Connection`.
- **Error Handling**:
  - Returns appropriate HTTP status codes (`200 OK`, `404 Not Found`, `403 Forbidden`, etc.).
- **Logging**: Logs client requests and server responses to `server.log`.

---

## Setup Instructions

1. Clone the Repository

2. Prepare the httpdoc Directory:
- Ensure the httpdoc directory contains the files you want to serve (e.g., index.html, helloworld.html).

3. Run the Server:
- Start the server by typing: python Server.python
- The server will listen on 127.0.0.1:8080

4. Run the Client:
- Use the client to send HTTP requests to the server by typing: python Client.py 

---

## Usage

### Server

- The server listens on 127.0.0.1:8080 and serves files from the httpdoc directory.
- Logs client requests and server responses to server.log.

### Client

- The client sends HTTP requests to the server and displays the responses.
- Example requests:
    - GET /index.html HTTP/1.1
    - HEAD /helloworld.html HTTP/1.1
    - GET /nonexistentfile.html HTTP/1.1

---

## Supported HTTP Methods

1. GET:
- Retrieves the content of a file.
- Example: GET /index.html HTTP/1.1

2. HEAD:
- Retrieves only the headers of a file.
- Example: HEAD /index.html HTTP/1.1

3. Error Handling:
- 404 Not Found: File does not exist.
- 403 Forbidden: File exists but is not readable.
- 415 Unsupported Media Type: File type is unsupported.
- 400 Bad Request: Invalid or unsupported HTTP request

---

## Log File

The server logs client requests and server responses to server.log. Each log entry includes:
- Client IP address
- Access time
- Requested file name
- Response type (e.g., 200 OK, 404 Not Found)

---

## Example Test Cases

1. GET Request for an Existing File:
- Request: GET /helloworld.html HTTP/1.1
- Response: 200 OK

2. HEAD Request for an Existing File:
- Request: HEAD /helloworld.html HTTP/1.1
- Response: 200 OK

3. POST Request for an Existing File:
- Request: POST /helloworld.html HTTP/1.1
-Response: 400 Bad Request

4. GET Request for a Non-Existent File:
- Request: GET /nonexistentfile.html HTTP/1.1
- Response: 404 Not Found

5. GET Request for another Existing File:
- Request: GET /index.html HTTP/1.1

6. GET Request for an Unsupported File Type:
- Request: GET /helloworld.pdf HTTP/1.1
- Response: 415 Unsupported Media Type

7. GET Request for a Forbidden File:
- Request: GET /forbidden.html HTTP/1.1
- Response: 403 Forbidden

