# Implements a simple HTTP Server
import socket
import os   
import time
import threading
import logging

def get_file_type(filename):
    # Determine the file type based on the file extension
    if filename.endswith('.txt'):
        return 'text/plain'
    elif filename.endswith(('.jpg', '.jpeg','.png', '.gif')):
        return 'image/*'
    elif filename.endswith('.html'):
        return 'text/html'
    else:
        return None # Default type for unknown files

def generate_http_response(status_code, headers, body = ''):
    # Generate the HTTP response header
    response_line = f'HTTP/1.1 {status_code}\n'
    headers = ''.join([f'{key}:{value}\n' for key, value in headers.items()])
    blank_line = '\n'
    return response_line + headers + blank_line + body

def handle_if_modified_since(headers, filepath):
    # Check if the file has been modified since the given date
    if 'If-Modified-Since' in headers:
        last_modified = time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(os.path.getmtime(filepath)))
        if headers['If-Modified-Since'] == last_modified:
            return generate_http_response('304 Not Modified', {})
    return None

def handle_connection_header(client_connection, headers):
    # Check if the connection header is present
    if 'Connection' in headers:
        if headers['Connection'] == 'close':
            client_connection.close()
        else:
            client_connection.settimeout(None)  # Set a timeout for the connection

# Handle the HTTP request
def handle_request(request):
    
    # Parse HTTP headers
    headers = request.split('\n')
    fields = headers[0].split()
    request_type = fields[0]  
    filename = fields[1]
    filepath = os.path.join('httpdoc', filename.strip('/'))
	
    headers = {header.split(':')[0]: header.split(':')[1].strip() for header in headers[1:] if ':' in header}

    # Parse the request type
    if not os.path.exists(filepath):
        return generate_http_response('404 Not Found', {})
    
    if os.path.isdir(filepath):
        return generate_http_response('404 Not Found', {})
    
    if not os.access(filepath, os.R_OK):
        return generate_http_response('403 Forbidden', {})
        
    file_type = get_file_type(filename)
    if not file_type:
        # Check if the file type is supported
        return generate_http_response('415 Unsupported Media Type', {})

    if request_type == 'GET':
        # Handle GET request
        if filename == '/':
            filename = '/index.html'
                
        response = handle_if_modified_since(headers, filepath)
        if response:
            return response
        
        try:
            fin= open('httpdoc' + filename)
            content = fin.read()
            headers.update({    
                'Content-Type': file_type,
                'Content-Length': str(len(content)),
                'Last-Modified': time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(os.path.getmtime(filepath)))
                })

            fin.close()
                    
            return generate_http_response('200 OK', headers, content)
        except FileNotFoundError:
            return generate_http_response('404 Not Found', {})
        except PermissionError:
            return generate_http_response('403 Forbidden', {})
        
    elif request_type == 'HEAD':
        # Handle HEAD request
        headers = {
            'Content-Type': file_type,
            'Content-Length': str(os.path.getsize(filepath)),
            'Last-Modified': time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(os.path.getmtime(filepath))),
            }
        return generate_http_response('200 OK', headers, '')
    else:
        return generate_http_response('400 Bad Request', {})		    

logging.basicConfig(
    filename='server.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

def handle_client(client_connection):
    # Handle the client connection
    try:
        # Get the client request
        request = client_connection.recv(4096).decode()
        print('Request:\n', request)
        
        headers = request.split('\n')
        fields = headers[0].split()
        request_type = fields[0] if len(fields) > 0 else "UNKNOWN"
        filename = fields[1] if len(fields) > 1 else "UNKNOWN"

        # Send HTTP response
        response = handle_request(request)
        client_connection.sendall(response.encode())

        client_address = client_connection.getpeername()[0]
        logging.info(f"Client {client_address}, File: {filename}, Response: {response.split()[1]}")
    except Exception as e:
        print(f"Error handling client request: {e}")
    finally:
        client_connection.close()

# Define socket host and port
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8080

# Create socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((SERVER_HOST, SERVER_PORT))
server_socket.listen(5)
print('Listening on port %s ...' % SERVER_PORT)

while True:
    # Wait for client connections
    client_connection, client_address = server_socket.accept()

    # Create a new thread to handle the client connection
    client_thread = threading.Thread(target=handle_client, args=(client_connection,))
    client_thread.start()

# Close socket
server_socket.close()
