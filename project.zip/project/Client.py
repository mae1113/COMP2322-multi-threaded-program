# Implements a simple HTTP client
import socket
import os

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8080

def send_http_request(request_type, file_path, connection_type):
    # Create a socket object
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        try:
            # Connect to the server
            client_socket.connect((SERVER_HOST, SERVER_PORT))

            # Define the request type and file path
            request = f'{request_type} {file_path} HTTP/1.1\r\n'
            request += f'Host: {SERVER_HOST}\r\n'
            request += f'Connection: {connection_type}\r\n'
            request += '\r\n'  # End of headers

            # Send the request to the server
            client_socket.sendall(request.encode())

            # Receive the response from the server
            response = client_socket.recv(1024)
    
            # Print the server response
            print('Server response:\n')
            print(response.decode())
  
            # Close the socket connection
            client_socket.close()
        except socket.error as e:
            print(f"Socket error: {e}")

# Example usage
if __name__ == '__main__':

    # The following lines are tests.
    # Send a GET request to the server --> HTTP/1.1 200 OK
    send_http_request('GET', '/helloworld.html', 'keep-alive')
    
    # Send a HEAD request to the server --> HTTP/1.1 200 OK
    send_http_request('HEAD', '/helloworld.html', 'close')
    
    # Send a POST request to the server --> HTTP/1.1 400 Bad Request
    send_http_request('POST', '/helloworld.html', 'close')

    # Send a GET request to a non-existent file --> HTTP/1.1 404 Not Found
    send_http_request('GET', '/nonexistentfile.html', 'close')

    # Send a GET request to the server with a different file --> HTTP/1.1 200 OK
    send_http_request('GET', '/index.html', 'close')

    # Send a GET request to an unsupported file --> HTTP/1.1 415 Unsupported Media Type
    send_http_request('GET', '/helloworld.pdf', 'close')
    
    # Send a resquest with a with the s\ame file --> HTTP/1.1 403 Forbidden
    send_http_request('GET', '/forbidden.html', 'close')

    